require("dotenv").config()
const express=require("express");
const bodyParser=require("body-parser");
const jwt=require("jsonwebtoken");
const nodemailer=require("nodemailer");
const bcrypt=require("bcrypt");
const cookieParser=require("cookie-parser");
const {
    createPool
} = require("mysql");


const pool = createPool({
    host:"sql917.main-hosting.eu",
    user: "u813107398_tushar",
    password:"Tushar@1",
    database:"u813107398_tushar",
    connectionLimit:10
})

const app=express();


app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));
app.use(cookieParser());

var login_user;
var login_valid=0;
var register_valid=0;

const isAuth= (req,res,next)=>{
    
    if(req.cookies.stoild===undefined){
        login_user=false;
        next();
    }
    else{
        const token= req.cookies.stoild;
        try{
             jwt.verify(token,process.env.SECRET_KEY);
            login_user=true;
            next();
         }catch(e){
            console.log(e);
            login_user=false;
            next();
        
        }
        

    }
}

const isAuth1=async (req,res)=>{
    
    if(await req.cookies.jwt===undefined){
        res.redirect("/login");
    }
    else{
        const token=await req.cookies.jwt;
        try{
            await jwt.verify(token,process.env.SECRET_KEY);
            next();
        }catch(e){
            console.log(e);
            res.redirect("/login");
        }
        

    }
}


app.get("/",isAuth,(req,res)=>{
    res.render("index",{loginUser: login_user});
})

app.get("/faq",isAuth,(req,res)=>{
    res.render("faq",{loginUser: login_user});

})

app.get("/login",(req,res)=>{
    res.render("login",{login_valid: login_valid});

})

app.post("/login",(req,res)=>{
    const Email= req.body.email;
    const Password= req.body.password;
    const string='select * from login where username= "'+ Email +'"';
    pool.query(string,async (err,result)=>{
        if(err){
            return console.log(err);
        }
        else{
            if(result.length==0)
            {
                var login_valid=1;
                res.redirect("/login");
            }
            else{
                const isMatch=await bcrypt.compare(Password, result[0].password);
                
                if(isMatch){
                    const token= jwt.sign({
                    },process.env.SECRET_KEY)
                    res.cookie("stoild",token,{
                        expires: new Date(Date.now()+ 24*60*60*1000*3),
                        httpOnly: true
                    })
                    res.cookie("userid",result[0].userid,{
                        expires: new Date(Date.now()+ 24*60*60*1000*3),
                        httpOnly: true
                    })
                    res.redirect("/");
                }
                else{
                    var login_valid=2;
                    res.redirect("/login");
                }
    
            }
        }
    })

  })

app.post("/register", (req,res2)=>{
    const Fname= req.body.Fname;
    const Lname= req.body.Lname;
    const Email= req.body.Email;
    const Password= req.body.Password;
    const ConfirmPassword= req.body.Confirm_password;
    const string='select * from login where username= "'+ Email +'"';
    let users=0;
    pool.query("select * from login",(err,result)=>{
        if(err){
            return console.log(err);
        }
        else{
            users=result.length;
            pool.query(string, async (er,res)=>{
                if(er){
                    return console.log(er);
                }
                else{
                    if(res.length==1)
                    {
                        var register_valid=1;
                        res2.redirect("/register");
                    }
                    else{
                        if(Password != ConfirmPassword){
                            var login_valid=2;
                            res2.redirect("/register");
                        }
                        else{
                            const encryptPassword=  await bcrypt.hash(Password,10);
                            const insert='INSERT into  login(userid,firstname,lastname,username,password)values("'+ users +'","'+Fname+'","'+Lname+'","'+Email+'","'+encryptPassword+'")';
                            pool.query(insert, (e,res1)=>{
                                if(e){
                                    return console.log(e);
                                }
                                const token= jwt.sign({
                                },process.env.SECRET_KEY)
                                res2.cookie("stoild",token,{
                                    expires: new Date(Date.now()+ 24*60*60*1000*3),
                                    httpOnly: true
                                })
                                res2.cookie("userid",users,{
                                    expires: new Date(Date.now()+ 24*60*60*1000*3),
                                    httpOnly: true
                                })
                                res2.redirect("/");
                            })
                        }
            
                    }
                }
            })
        }

    })
    
  

  })

app.get("/register",(req,res)=>{
    res.render("Register",{register_valid: register_valid});

})

app.get("/logout",(req,res)=>{
    res.clearCookie("stoild");
    res.clearCookie("userid");
    res.redirect("/");
})

app.get("/philosophy",isAuth,(req,res)=>{
    res.render("philisophy",{loginUser: login_user});

})

app.get("/download",isAuth,(req,res)=>{
    res.render("download",{loginUser: login_user});

})

app.get("/how-to-play",isAuth,(req,res)=>{
    res.render("how",{loginUser: login_user});

})

app.get("/privacy-policy",isAuth,(req,res)=>{
    res.render("privacy",{loginUser: login_user});

})

app.get("/terms-and-condition",isAuth,(req,res)=>{
    res.render("terms",{loginUser: login_user});

})

// app.get("/checkout",isAuth1,(req,res)=>{
//     res.sendFile(__dirname + "/checkout.html")
// })

app.listen(3000,()=>{
    console.log("Server started at 3000");
})
